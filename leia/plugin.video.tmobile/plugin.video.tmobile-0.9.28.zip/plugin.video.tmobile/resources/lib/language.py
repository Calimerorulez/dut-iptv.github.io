from resources.lib.base.language import BaseLanguage

class Language(BaseLanguage):
    START_FROM_BEGINNING = 32093
    
_ = Language()