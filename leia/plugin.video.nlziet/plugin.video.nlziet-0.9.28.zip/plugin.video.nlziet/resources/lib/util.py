def update_settings():
    pass